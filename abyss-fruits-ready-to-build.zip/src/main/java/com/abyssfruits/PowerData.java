package com.abyssfruits;

import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.world.entity.player.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Stores which fruit power a player has (persistent, survives death) + cooldowns. */
public final class PowerData {
    public static final AttachmentType<String> POWER = AttachmentRegistry.create(
            AbyssFruits.id("power"),
            builder -> builder.persistent(Codec.STRING).copyOnDeath());

    private static final Map<UUID, long[]> COOLDOWNS = new HashMap<>();

    private PowerData() {}

    public static FruitType get(Player p) {
        String s = p.getAttached(POWER);
        return s == null ? null : FruitType.byId(s);
    }

    public static void set(Player p, FruitType t) {
        if (t == null) p.removeAttached(POWER);
        else p.setAttached(POWER, t.id);
    }

    public static long readyAt(Player p, int idx) {
        long[] a = COOLDOWNS.get(p.getUUID());
        return a == null ? 0 : a[idx];
    }

    public static void setReadyAt(Player p, int idx, long time) {
        COOLDOWNS.computeIfAbsent(p.getUUID(), k -> new long[2])[idx] = time;
    }

    public static void clearCooldowns() {
        COOLDOWNS.clear();
    }
}
