package com.abyssfruits.client;

import com.abyssfruits.AbilityPayload;
import com.abyssfruits.AbyssFruits;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.particle.FlameParticle;
import org.lwjgl.glfw.GLFW;

public class AbyssFruitsClient implements ClientModInitializer {
    public static final ModelLayerLocation WRAITH_LAYER =
            new ModelLayerLocation(AbyssFruits.id("shadow_wraith"), "main");

    private static KeyMapping ability1, ability2;

    @Override
    public void onInitializeClient() {
        // ---- keys: R = ability 1, G = ability 2 (rebindable in Controls)
        KeyMapping.Category cat = KeyMapping.Category.register(AbyssFruits.id("main"));
        ability1 = KeyBindingHelper.registerKeyBinding(
                new KeyMapping("key.abyssfruits.ability1", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R, cat));
        ability2 = KeyBindingHelper.registerKeyBinding(
                new KeyMapping("key.abyssfruits.ability2", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, cat));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (ability1.consumeClick()) {
                if (mc.player != null) ClientPlayNetworking.send(new AbilityPayload(0));
            }
            while (ability2.consumeClick()) {
                if (mc.player != null) ClientPlayNetworking.send(new AbilityPayload(1));
            }
        });

        // ---- particles (textures live in assets/abyssfruits/textures/particle + particles/*.json)
        ParticleFactoryRegistry reg = ParticleFactoryRegistry.getInstance();
        reg.register(AbyssFruits.SHADOW_WISP, FlameParticle.Provider::new);
        reg.register(AbyssFruits.BLOOD_DROP, FlameParticle.Provider::new);
        reg.register(AbyssFruits.BLACK_EMBER, FlameParticle.Provider::new);
        reg.register(AbyssFruits.GRAVITY_ORB, FlameParticle.Provider::new);

        // ---- wraith: custom 3D model + renderer
        EntityModelLayerRegistry.registerModelLayer(WRAITH_LAYER, WraithModel::createLayer);
        EntityRendererRegistry.register(AbyssFruits.WRAITH, WraithRenderer::new);
    }
}
