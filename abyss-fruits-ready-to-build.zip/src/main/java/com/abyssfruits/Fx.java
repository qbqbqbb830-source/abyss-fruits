package com.abyssfruits;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;

/** Particle + sound helpers (all server-side; particles are synced to clients). */
public final class Fx {
    private Fx() {}

    public static ParticleOptions blood() { return new DustParticleOptions(0xA00010, 1.5f); }
    public static ParticleOptions darkDust() { return new DustParticleOptions(0x1A0A28, 1.6f); }
    public static ParticleOptions gravityDust() { return new DustParticleOptions(0x6A8CFF, 1.2f); }

    public static void burst(ServerLevel l, ParticleOptions p, Vec3 pos, int count, double spread, double speed) {
        l.sendParticles(p, pos.x, pos.y, pos.z, count, spread, spread, spread, speed);
    }

    public static void ring(ServerLevel l, ParticleOptions p, Vec3 c, double radius, int points, double yOff) {
        for (int i = 0; i < points; i++) {
            double a = Math.PI * 2 * i / points;
            l.sendParticles(p, c.x + Math.cos(a) * radius, c.y + yOff, c.z + Math.sin(a) * radius, 1, 0, 0, 0, 0);
        }
    }

    /** Ring whose particles fly inward (negative) or outward (positive) at the given speed. */
    public static void movingRing(ServerLevel l, ParticleOptions p, Vec3 c, double radius, int points, double yOff, double speed) {
        for (int i = 0; i < points; i++) {
            double a = Math.PI * 2 * i / points;
            double dx = Math.cos(a), dz = Math.sin(a);
            l.sendParticles(p, c.x + dx * radius, c.y + yOff, c.z + dz * radius, 0, dx, 0.05, dz, speed);
        }
    }

    public static void line(ServerLevel l, ParticleOptions p, Vec3 a, Vec3 b, double step) {
        Vec3 d = b.subtract(a);
        double len = d.length();
        if (len < 0.01) return;
        Vec3 n = d.scale(1.0 / len);
        for (double t = 0; t <= len; t += step) {
            Vec3 q = a.add(n.scale(t));
            l.sendParticles(p, q.x, q.y, q.z, 1, 0.05, 0.05, 0.05, 0.0);
        }
    }

    public static void sound(ServerLevel l, Vec3 pos, SoundEvent s, float vol, float pitch) {
        l.playSound(null, pos.x, pos.y, pos.z, s, SoundSource.PLAYERS, vol, pitch);
    }

    public static double distToSegment(Vec3 p, Vec3 a, Vec3 b) {
        Vec3 ab = b.subtract(a);
        double len2 = ab.lengthSqr();
        double t = len2 == 0 ? 0 : Math.max(0, Math.min(1, p.subtract(a).dot(ab) / len2));
        return p.distanceTo(a.add(ab.scale(t)));
    }
}
