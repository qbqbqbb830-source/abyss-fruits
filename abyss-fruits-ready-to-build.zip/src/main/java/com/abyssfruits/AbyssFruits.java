package com.abyssfruits;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Registry;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import java.util.EnumMap;
import java.util.Map;
import java.util.function.Function;

public class AbyssFruits implements ModInitializer {
    public static final String MOD_ID = "abyssfruits";

    public static final Map<FruitType, Item> FRUITS = new EnumMap<>(FruitType.class);
    public static SimpleParticleType SHADOW_WISP, BLOOD_DROP, BLACK_EMBER, GRAVITY_ORB;
    public static EntityType<ShadowWraith> WRAITH;
    public static Item WRAITH_EGG;

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    private static SimpleParticleType particle(String name) {
        return Registry.register(BuiltInRegistries.PARTICLE_TYPE, id(name), FabricParticleTypes.simple());
    }

    private static Item item(String name, Function<Item.Properties, Item> factory, Item.Properties props) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id(name));
        return Registry.register(BuiltInRegistries.ITEM, key, factory.apply(props.setId(key)));
    }

    @Override
    public void onInitialize() {
        // ---- particles
        SHADOW_WISP = particle("shadow_wisp");
        BLOOD_DROP = particle("blood_drop");
        BLACK_EMBER = particle("black_ember");
        GRAVITY_ORB = particle("gravity_orb");

        // ---- fruits
        for (FruitType t : FruitType.values()) {
            FRUITS.put(t, item(t.id + "_fruit", p -> new FruitItem(p, t),
                    new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)
                            .food(new FoodProperties.Builder().nutrition(2).saturationModifier(0.3f).alwaysEdible().build())));
        }

        // ---- entity
        ResourceKey<EntityType<?>> ek = ResourceKey.create(Registries.ENTITY_TYPE, id("shadow_wraith"));
        WRAITH = Registry.register(BuiltInRegistries.ENTITY_TYPE, ek,
                EntityType.Builder.of(ShadowWraith::new, MobCategory.MONSTER)
                        .sized(0.6f, 2.1f).clientTrackingRange(10).build(ek));
        FabricDefaultAttributeRegistry.register(WRAITH, ShadowWraith.createAttributes());
        WRAITH_EGG = item("shadow_wraith_spawn_egg", Item::new, new Item.Properties().spawnEgg(WRAITH));

        // ---- creative tabs
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.FOOD_AND_DRINKS)
                .register(e -> FRUITS.values().forEach(e::accept));
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.SPAWN_EGGS)
                .register(e -> e.accept(WRAITH_EGG));

        // ---- networking (key press -> server)
        // NOTE: if this line fails to compile on your Fabric API, use PayloadTypeRegistry.serverboundPlay()
        PayloadTypeRegistry.playC2S().register(AbilityPayload.TYPE, AbilityPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(AbilityPayload.TYPE,
                (payload, ctx) -> Abilities.use(ctx.player(), payload.index()));

        // ---- server loop: scheduler, aura FX, hostile wraith spawns
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            Scheduler.tick();
            for (ServerLevel level : server.getAllLevels()) {
                long g = level.getGameTime();
                for (ServerPlayer p : level.players()) {
                    FruitType t = PowerData.get(p);
                    if (t == null || p.isSpectator()) continue;
                    if (g % 3 == 0) Abilities.aura(level, p, t);
                    if (g % 1200 == 0 && !p.isCreative() && level.dimension().equals(Level.OVERWORLD)
                            && level.getRandom().nextFloat() < 0.35f) {
                        spawnHunter(level, p);
                    }
                }
            }
        });
        ServerLifecycleEvents.SERVER_STOPPED.register(s -> {
            Scheduler.clear();
            PowerData.clearCooldowns();
        });
    }

    /** A hostile wraith appears near a fruit user (anyone who ate a fruit is hunted). */
    private static void spawnHunter(ServerLevel level, ServerPlayer p) {
        int near = level.getEntitiesOfClass(ShadowWraith.class, p.getBoundingBox().inflate(48),
                w -> w.getOwnerId() == null).size();
        if (near >= 2) return;
        ShadowWraith w = WRAITH.create(level, EntitySpawnReason.EVENT);
        if (w == null) return;
        double a = level.getRandom().nextDouble() * Math.PI * 2;
        double d = 14 + level.getRandom().nextDouble() * 8;
        BlockPos top = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                BlockPos.containing(p.getX() + Math.cos(a) * d, 0, p.getZ() + Math.sin(a) * d));
        w.setPos(top.getX() + 0.5, top.getY(), top.getZ() + 0.5);
        level.addFreshEntity(w);
        Fx.burst(level, SHADOW_WISP, new Vec3(top.getX() + 0.5, top.getY() + 1, top.getZ() + 0.5), 40, 0.6, 0.1);
        Fx.sound(level, w.position(), net.minecraft.sounds.SoundEvents.WARDEN_AMBIENT, 1.2f, 0.7f);
    }
}
